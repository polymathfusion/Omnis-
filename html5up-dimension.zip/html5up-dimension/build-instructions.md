# How to Convert Your HTML App to Android APK

## Prerequisites

1. **Install Node.js** (Required for Cordova)
   - Download from: https://nodejs.org/
   - Choose LTS version
   - Install with default settings

2. **Install Java JDK** (Required for Android development)
   - Download from: https://adoptium.net/
   - Choose JDK 11 or 17
   - Install with default settings

3. **Install Android Studio** (Required for Android SDK)
   - Download from: https://developer.android.com/studio
   - Install with default settings
   - Open Android Studio and install Android SDK

## Step-by-Step Instructions

### 1. Install Cordova Globally
```bash
npm install -g cordova
```

### 2. Navigate to Your Project Directory
```bash
cd "C:\Users\ABDULRAZAK\Desktop\Aaa\html5up-dimension"
```

### 3. Initialize Cordova Project
```bash
cordova create omnis-app com.omnis.app Omnis
cd omnis-app
```

### 4. Copy Your Files
- Copy all files from your current directory to `omnis-app/www/`
- Replace the default `www/index.html` with your custom one
- Copy `assets/` folder to `www/assets/`

### 5. Add Android Platform
```bash
cordova platform add android
```

### 6. Add Required Plugins
```bash
cordova plugin add cordova-plugin-whitelist
cordova plugin add cordova-plugin-device
cordova plugin add cordova-plugin-network-information
cordova plugin add cordova-plugin-file
cordova plugin add cordova-plugin-camera
cordova plugin add cordova-plugin-file-transfer
```

### 7. Set Android SDK Path
Set these environment variables:
```bash
set ANDROID_HOME=C:\Users\[YourUsername]\AppData\Local\Android\Sdk
set ANDROID_SDK_ROOT=C:\Users\[YourUsername]\AppData\Local\Android\Sdk
```

### 8. Build the APK
```bash
cordova build android
```

### 9. Find Your APK
The APK will be located at:
```
omnis-app/platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

## Alternative: Using Online Build Services

If you prefer not to install everything locally, you can use:

### 1. PhoneGap Build (Adobe)
- Upload your project to: https://build.phonegap.com/
- Sign up for free account
- Upload your project files
- Build online

### 2. Appetize.io
- Similar online build service
- Free tier available

### 3. BuildFire
- Another online app builder
- Drag-and-drop interface

## Troubleshooting

### Common Issues:

1. **"cordova command not found"**
   - Reinstall Node.js and Cordova
   - Restart command prompt

2. **"Android SDK not found"**
   - Install Android Studio
   - Set ANDROID_HOME environment variable
   - Add platform-tools to PATH

3. **"Java not found"**
   - Install Java JDK
   - Set JAVA_HOME environment variable

4. **Build fails**
   - Check all prerequisites are installed
   - Ensure Android SDK is properly configured
   - Try: `cordova clean android` then rebuild

## Testing Your APK

1. **Install on Device**
   - Enable "Unknown Sources" in Android settings
   - Transfer APK to device and install

2. **Test Features**
   - Dictionary search
   - Translation
   - Notes functionality
   - Sidebar navigation

## Publishing to Google Play Store

1. **Sign the APK**
   ```bash
   cordova build android --release
   ```

2. **Create Keystore**
   ```bash
   keytool -genkey -v -keystore my-release-key.keystore -alias alias_name -keyalg RSA -keysize 2048 -validity 10000
   ```

3. **Sign with Keystore**
   ```bash
   jarsigner -verbose -sigalg SHA1withRSA -digestalg SHA1 -keystore my-release-key.keystore app-release-unsigned.apk alias_name
   ```

4. **Optimize APK**
   ```bash
   zipalign -v 4 app-release-unsigned.apk Omnis.apk
   ```

## File Structure After Setup

```
omnis-app/
├── config.xml
├── package.json
├── www/
│   ├── index.html
│   ├── assets/
│   │   ├── css/
│   │   └── js/
│   └── cordova.js
├── platforms/
│   └── android/
└── plugins/
```

## Quick Start (If you have everything installed)

```bash
# 1. Install Cordova
npm install -g cordova

# 2. Create project
cordova create omnis-app com.omnis.app Omnis

# 3. Add platform
cd omnis-app
cordova platform add android

# 4. Copy your files to www/
# (Copy your index.html and assets folder)

# 5. Build
cordova build android

# 6. Find APK in platforms/android/app/build/outputs/apk/debug/
```

Your APK will be ready to install on Android devices! 